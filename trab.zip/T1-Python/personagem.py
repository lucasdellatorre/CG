class Personagem():
    def __init__(self, modelo) -> None:
        self.modelo = modelo

    def Desenha(self):
        pass
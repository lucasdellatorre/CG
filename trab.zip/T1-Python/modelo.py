class ModeloMatricial():
    def __init__(self, filepath) -> None:
        self.matrix = le_modelo()

    def le_modelo(self):
        return [
            [1, 1, 1]
            [1, 0, 1]
            [1, 1, 1]
        ]

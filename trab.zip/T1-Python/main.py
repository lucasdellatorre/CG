# ***********************************************************************************
#   Para construir este programa, foi utilizada a biblioteca PyOpenGL, disponível em
#   http://pyopengl.sourceforge.net/documentation/index.html
#
#   Sugere-se consultar também as páginas listadas
#   a seguir:
#   http://bazaar.launchpad.net/~mcfletch/pyopengl-demo/trunk/view/head:/PyOpenGL-Demo/NeHe/lesson1.py
#   http://pyopengl.sourceforge.net/documentation/manual-3.0/index.html#GLUT
#
#   No caso de usar no MacOS, pode ser necessário alterar o arquivo ctypesloader.py,
#   conforme a descrição que está nestes links:
#   https://stackoverflow.com/questions/63475461/unable-to-import-opengl-gl-in-python-on-macos
#   https://stackoverflow.com/questions/6819661/python-location-on-mac-osx
#   Veja o arquivo Patch.rtf, armazenado na mesma pasta deste fonte.
# ***********************************************************************************

from OpenGL.GL import *
from OpenGL.GLUT import *
from OpenGL.GLU import *
from TransformacoesGeometricas import Instancia
# from Basico import Ponto

Personagens = []

def DesenhaCatavento():
    glLineWidth(3)
    glPushMatrix()
    # DesenhaMastro()
    glPushMatrix()
    glColor3f(1,0,0)
    glTranslated(0,3,0)
    glScaled(0.2, 0.2, 1)
    # DesenhaHelicesGirando()
    glPopMatrix()
    glPopMatrix()

def criaInstancias():
    global Personagens

    Personagens.append(Instancia())
    Personagens[0].modelo = DesenhaCatavento
    Personagens[0].rotacao = 0
    # Personagens[0].posicao = Ponto(1,1)
    # Personagens[0].escala = Ponto (1,1,1) 

def desenhaPersonagens():
    for i in Personagens:
        i.Desenha()

    pass

def display():
	# Limpa a tela coma cor de fundo
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    glLoadIdentity()

    desenhaPersonagens()

    glutSwapBuffers()

def animate():
    glutPostRedisplay()

def init():
    # Define a cor do fundo da tela (PRETO)
    glClearColor(0, 0, 0, 0)

    criaInstancias()

# ***********************************************************************************
# Programa Principal
# ***********************************************************************************

DISPLAY_WIDTH=800
DISPLAY_HEIGHT=600

INITIAL_DISPLAY_POSITION_WIDTH=300
INITIAL_DISPLAY_POSITION_HEIGHT=75

DISPLAY_GAME_TITLE="Space Invaders"

glutInit(sys.argv)
glutInitDisplayMode(GLUT_RGBA)
# Define o tamanho inicial da janela grafica do programa
glutInitWindowSize(DISPLAY_WIDTH, DISPLAY_HEIGHT)
glutInitWindowPosition(INITIAL_DISPLAY_POSITION_WIDTH, INITIAL_DISPLAY_POSITION_HEIGHT)
wind = glutCreateWindow(DISPLAY_GAME_TITLE)
glutDisplayFunc(display)
# glutIdleFunc(animate)
# glutKeyboardFunc(keyboard)
# glutSpecialFunc(arrow_keys)
# glutMouseFunc(mouse)
init()

try:
    glutMainLoop()
except SystemExit:
    pass